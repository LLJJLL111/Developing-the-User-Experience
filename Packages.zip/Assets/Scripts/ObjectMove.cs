using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectMove : MonoBehaviour
{
    // 1. Public variable: Used to manually specify the object to control in the Inspector window (e.g., your house)
    public GameObject targetObject;

    // 2. Private variables: Used to store the object's initial state (position, rotation, scale)
    private Transform targetTransform;
    private Vector3 initialPosition;
    private Quaternion initialRotation;
    private Vector3 initialScale;

    // 3. Start method: Executed once at the start of the game
    void Start()
    {
        // Get the target object's Transform component
        targetTransform = targetObject.transform;

        // Record the object's current initial state
        initialPosition = targetTransform.position;
        initialRotation = targetTransform.rotation;
        initialScale = targetTransform.localScale;
    }

    // --- Button function methods ---

    // Return to main menu
    public void BackToMenu()
    {
        // Fill in the logic to return to main menu here
        Debug.Log("Return to main menu");
    }

    // Move backward
    public void Back()
    {
        targetTransform.Translate(Vector3.back);
    }

    // Move forward
    public void Advance()
    {
        targetTransform.Translate(Vector3.forward);
    }

    // Move left
    public void Left()
    {
        targetTransform.Translate(Vector3.left);
    }

    // Move right
    public void Right()
    {
        targetTransform.Translate(Vector3.right);
    }

    // Scale up
    public void ScaleUp()
    {
        targetTransform.localScale += new Vector3(0.1f, 0.1f, 0.1f);
    }

    // Scale down
    public void ScaleDown()
    {
        targetTransform.localScale -= new Vector3(0.1f, 0.1f, 0.1f);
    }

    // Rotate left
    public void RotateLeft()
    {
        targetTransform.Rotate(Vector3.up, -5f);
    }

    // Rotate right
    public void RotateRight()
    {
        targetTransform.Rotate(Vector3.up, 5f);
    }

    // Reset: Return to initial position, rotation, and scale
    public void Reset()
    {
        targetTransform.position = initialPosition;
        targetTransform.rotation = initialRotation;
        targetTransform.localScale = initialScale;
    }
}